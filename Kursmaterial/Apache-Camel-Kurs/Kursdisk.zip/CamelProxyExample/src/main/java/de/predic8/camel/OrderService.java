package de.predic8.camel;


public interface OrderService {

	public String order(String string);

}
