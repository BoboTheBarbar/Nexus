package de.predic8.camel.webservice;

public interface HelloService {
	public String sayHello();
}
