# Sample
http://localhost:8080/supplier/?food=Potatoes